create view prod_img_view as (select
                                `p`.`id`           AS `id`,
                                `p`.`cid`          AS `cid`,
                                `p`.`name`         AS `pname`,
                                `p`.`promotePrice` AS `promotePrice`,
                                `pi`.`id`          AS `imgId`
                              from (`tmall`.`product` `p`
                                join `tmall`.`productimage` `pi`)
                              where (`p`.`id` = `pi`.`pid`));

